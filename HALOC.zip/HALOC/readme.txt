training: 0.csv, 1.csv, 2.csv and 3.csv
validation: 4.csv
test: 5.csv